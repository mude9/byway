# Byway Tool on GitHub Pages

## Quick publish
1. Create a new public repository on GitHub, for example: `byway-tool`
2. Upload all files from this folder to the root of the repository
3. On GitHub go to:
   - Settings
   - Pages
   - Under Build and deployment
   - Set Source to Deploy from a branch
   - Choose Branch: main
   - Choose Folder: /(root)
   - Save
4. Wait 1-3 minutes
5. Your site will appear at:
   https://YOUR-USERNAME.github.io/byway-tool/

## Files
- index.html -> the app
- README.md -> these instructions

## Google Maps
Inside the page, paste your Google Maps API Key in the field at the top.

## Important
- GitHub Pages works best from a real HTTPS URL, so it should work on mobile much better than sending the HTML file over WhatsApp.
- If Google Maps does not work, the manual distance input still works.
